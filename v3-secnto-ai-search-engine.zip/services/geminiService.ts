
import { GoogleGenAI, GenerateContentResponse, Part, Chat, Content, PartListUnion } from "@google/genai";
import { SearchType, Language, SearchResultItem, TextSearchResult, ImageSearchResult, VideoSearchResult, LocalSearchResult, GroundingSource, UserLocation, SearchFilterOptions, SearchSuggestion, SuggestionType, DominantResultPayload, DominantResultType, NotebookSource, NotebookChatMessage, NotebookSourceType } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Error Identifiers
const NETWORK_ERROR = "NETWORK_ERROR";
const API_KEY_INVALID = "API_KEY_INVALID";
const RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED";
const GENERIC_GEMINI_ERROR = "GENERIC_GEMINI_ERROR";
const GENERIC_STREAM_ERROR = "GENERIC_STREAM_ERROR";
const GENERIC_ASSISTANT_ERROR = "GENERIC_ASSISTANT_ERROR";
const GENERIC_NOTEBOOK_ERROR = "GENERIC_NOTEBOOK_ERROR";
const GENERIC_IMAGE_GENERATION_ERROR = "GENERIC_IMAGE_GENERATION_ERROR";


// Function to fetch images from Google Custom Search Engine API
// This function remains but will be less central to image search.
// It might still be called if a very specific, non-Gemini path to CSE images is ever needed,
// or as a fallback if Gemini image sourcing proves insufficient in some edge cases (though not implemented as such now).
export async function fetchImagesFromGoogleCSE( // Exported for App.tsx
  query: string,
  language: Language,
  filters?: SearchFilterOptions,
  startIndex: number = 1, // CSE uses 1-based indexing for start
  numResults: number = 10 // Default number of results for CSE
): Promise<ImageSearchResult[]> {
  const apiKey = process.env.GOOGLE_CSE_API_KEY;
  const cxId = process.env.GOOGLE_CSE_CX_ID;

  if (!apiKey || !cxId) {
    console.error("Google Custom Search API Key or CX ID not configured.");
    throw new Error(language === Language.Urdu ? "گوگل کسٹم سرچ API کلید یا CX ID کنفیگر نہیں ہے۔ تصاویر تلاش نہیں کی جا سکتیں۔" : "Google Custom Search API Key or CX ID not configured. Cannot fetch images.");
  }

  let url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cxId}&q=${encodeURIComponent(query)}&searchType=image&num=${numResults}&start=${startIndex}&hl=${language === Language.Urdu ? 'ur' : 'en'}`;

  if (filters?.imageSizeFilter && filters.imageSizeFilter !== 'any') {
    const cseImgSizeMap: { [key: string]: string } = {
      small: 'icon', 
      medium: 'medium',
      large: 'large', 
    };
    if (cseImgSizeMap[filters.imageSizeFilter]) {
      url += `&imgSize=${cseImgSizeMap[filters.imageSizeFilter]}`;
    }
  }
  
  url += `&fields=items(title,link,snippet,image/contextLink,htmlTitle,cacheId)`;


  try {
    const response = await fetch(url);
    if (!response.ok) {
      const errorData = await response.json();
      console.error("Google CSE API Error:", errorData);
      throw new Error(language === Language.Urdu ? `گوگل CSE API سے خرابی: ${errorData.error?.message || response.statusText}` : `Error from Google CSE API: ${errorData.error?.message || response.statusText}`);
    }
    const data = await response.json();
    
    if (!data.items) {
      return []; 
    }

    return data.items.map((item: any, idx: number) => ({
      id: `cse-img-${item.cacheId || (startIndex + idx)}-${Date.now()}`,
      type: SearchType.Images,
      imageUrl: item.link,
      caption: item.snippet || item.title || (language === Language.Urdu ? "تصویر" : "Image"), 
      pageTitle: item.htmlTitle || item.title || (language === Language.Urdu ? "ماخذ صفحہ" : "Source Page"),
      sourceUrl: item.image?.contextLink || '#',
    } as ImageSearchResult));

  } catch (error: any) {
    console.error('Failed to fetch images from Google CSE:', error);
    if (error.message.includes("API Key or CX ID not configured")) throw error;
    if (error.name === 'TypeError' && error.message.toLowerCase().includes('failed to fetch')) {
        throw new Error(NETWORK_ERROR);
    }
    throw new Error(language === Language.Urdu ? "گوگل کسٹم سرچ سے تصاویر حاصل کرنے میں ناکامی۔" : "Failed to fetch images from Google Custom Search.");
  }
}

// Helper function to parse a single image data string from Gemini
function parseGeminiImageString(
    imageDetailString: string,
    query: string,
    baseIdSuffix: string, // To ensure unique IDs
    itemIndex: number
): ImageSearchResult | null {
    const lines = imageDetailString.split('\n').map(line => line.trim());
    let imageUrl = '', caption = '', sourceUrl = '', pageTitle = '';

    lines.forEach(line => {
        if (line.toLowerCase().startsWith('imageurl:')) imageUrl = line.substring(9).trim();
        else if (line.toLowerCase().startsWith('caption:')) caption = line.substring(8).trim();
        else if (line.toLowerCase().startsWith('sourceurl:')) sourceUrl = line.substring(10).trim();
        else if (line.toLowerCase().startsWith('pagetitle:')) pageTitle = line.substring(10).trim();
    });

    if (imageUrl && caption && sourceUrl && pageTitle) {
        // Validate imageUrl (basic check)
        try {
            new URL(imageUrl); // throws if invalid
        } catch (e) {
            console.warn("Invalid image URL from Gemini:", imageUrl);
            return null;
        }

        return {
            id: `gem-img-${query}-${baseIdSuffix}-${itemIndex}-${Date.now()}`,
            type: SearchType.Images,
            imageUrl,
            caption,
            sourceUrl,
            pageTitle
        };
    }
    return null;
}


function parseGeminiResponse(
  responseText: string,
  searchType: SearchType,
  query: string,
  language: Language,
  startIndex: number = 0 // This startIndex is for the current batch of items from Gemini
): SearchResultItem[] {
  const items: SearchResultItem[] = [];
  const rawItems = responseText.split('---').map(item => item.trim()).filter(item => item);

  rawItems.forEach((rawItem, index) => {
    const lines = rawItem.split('\n').map(line => line.trim());
    let title = '', snippet = '', channel = '', name = '', category = '', address = '';
    let videoID = '', geminiVideoURL = '', geminiThumbnailURL = '';
    let latitude: number | null = null;
    let longitude: number | null = null;
    let parsedUrlValue: string | null = null;
    // For image type directly parsed here
    let imageUrl_img = '', caption_img = '', sourceUrl_img = '', pageTitle_img = '';


    lines.forEach(line => {
      // Note: SearchType.Images parsing is no longer primary here if CSE is used.
      // This parsing logic remains for cases where Gemini might provide image data (e.g., in "All" tab's dominant results).
      if (line.toLowerCase().startsWith('imageurl:')) imageUrl_img = line.substring(9).trim();
      else if (line.toLowerCase().startsWith('caption:')) caption_img = line.substring(8).trim();
      else if (line.toLowerCase().startsWith('sourceurl:')) sourceUrl_img = line.substring(10).trim();
      else if (line.toLowerCase().startsWith('pagetitle:')) pageTitle_img = line.substring(10).trim();
      else if (line.toLowerCase().startsWith('title:')) title = line.substring(6).trim();
      else if (line.toLowerCase().startsWith('url:')) {
        const potentialUrl = line.substring(4).trim();
        if (potentialUrl) {
          try {
            let urlObj = new URL(potentialUrl);
            parsedUrlValue = urlObj.href;
          } catch (e) {
            if (potentialUrl.includes('.') && !potentialUrl.includes(' ') && !potentialUrl.startsWith('http')) {
              try {
                let fullUrl = `https://${potentialUrl}`;
                new URL(fullUrl); 
                parsedUrlValue = fullUrl;
              } catch (e2) {
                parsedUrlValue = null; 
              }
            } else {
              parsedUrlValue = null;
            }
          }
        } else {
          parsedUrlValue = null;
        }
      }
      else if (line.toLowerCase().startsWith('snippet:')) snippet = line.substring(8).trim();
      else if (line.toLowerCase().startsWith('channel:')) channel = line.substring(8).trim();
      else if (line.toLowerCase().startsWith('videoid:')) videoID = line.substring(8).trim();
      else if (line.toLowerCase().startsWith('thumbnailurl:')) geminiThumbnailURL = line.substring(13).trim();
      else if (line.toLowerCase().startsWith('videourl:')) geminiVideoURL = line.substring(9).trim();
      else if (line.toLowerCase().startsWith('name:')) name = line.substring(5).trim();
      else if (line.toLowerCase().startsWith('category:')) category = line.substring(9).trim();
      else if (line.toLowerCase().startsWith('address:')) address = line.substring(8).trim();
      else if (line.toLowerCase().startsWith('latitude:')) {
        const latStr = line.substring(9).trim();
        const latVal = parseFloat(latStr);
        if (!isNaN(latVal)) latitude = latVal;
      } else if (line.toLowerCase().startsWith('longitude:')) {
        const lonStr = line.substring(10).trim();
        const lonVal = parseFloat(lonStr);
        if (!isNaN(lonVal)) longitude = lonVal;
      }
    });

    const id = `${query}-${searchType}-${startIndex + index}-${Date.now()}`;

    try {
      switch (searchType) {
        case SearchType.All:
        case SearchType.News:
          if (title && snippet) { 
             items.push({ 
                id, 
                type: searchType, 
                title, 
                url: parsedUrlValue, 
                snippet 
            } as TextSearchResult);
          } else if (rawItem.length > 10 && (searchType === SearchType.All || searchType === SearchType.News)) { 
             items.push({ 
                id, 
                type: searchType, 
                title: rawItem.substring(0, Math.min(50, rawItem.length)) + (rawItem.length > 50 ? "..." : ""), 
                url: parsedUrlValue, 
                snippet: rawItem 
            } as TextSearchResult);
          }
          break;
        case SearchType.Images: // This case in parseGeminiResponse can still be used for images found via general Gemini prompts (e.g. dominant results)
          if (imageUrl_img && caption_img && sourceUrl_img && pageTitle_img) {
              try {
                  new URL(imageUrl_img); // Validate URL
                  items.push({
                      id,
                      type: SearchType.Images,
                      imageUrl: imageUrl_img,
                      caption: caption_img,
                      sourceUrl: sourceUrl_img,
                      pageTitle: pageTitle_img
                  } as ImageSearchResult);
              } catch(e) {
                  console.warn("Invalid image URL from Gemini during parsing (parseGeminiResponse):", imageUrl_img);
              }
          }
          break;
        case SearchType.Videos:
          if (title || channel || (searchType === SearchType.Videos && rawItem)) {
            const finalVideoTitle = title || rawItem.substring(0, Math.min(50, rawItem.length));
            
            let thumbnailUrl = "";
            let videoUrl = "";
            const isValidYouTubeID = videoID && videoID !== "NOT_AVAILABLE" && /^[a-zA-Z0-9_-]{11}$/.test(videoID);
            
            if (isValidYouTubeID) {
              thumbnailUrl = `https://img.youtube.com/vi/${videoID}/mqdefault.jpg`;
              videoUrl = `https://www.youtube.com/watch?v=${videoID}`;
            } else {
              if (geminiThumbnailURL && geminiThumbnailURL !== "NOT_AVAILABLE") {
                try {
                  new URL(geminiThumbnailURL); 
                  thumbnailUrl = geminiThumbnailURL;
                } catch (e) {
                  thumbnailUrl = ""; 
                }
              }

              if (geminiVideoURL && geminiVideoURL !== "NOT_AVAILABLE") {
                  try {
                      new URL(geminiVideoURL); 
                      videoUrl = geminiVideoURL;
                  } catch(e) { /* Will use fallback to YouTube search if this also fails */ }
              }
            }

            if (!videoUrl) { 
                 videoUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(finalVideoTitle)}`;
            }

            items.push({ 
                id, 
                type: SearchType.Videos, 
                title: finalVideoTitle, 
                channel: channel || (language === Language.Urdu ? "نامعلوم چینل" : "Unknown Channel"), 
                thumbnailUrl: thumbnailUrl,
                videoUrl: videoUrl
            } as VideoSearchResult);
          }
          break;
        case SearchType.Local:
          if (name && category && address && latitude !== null && longitude !== null) {
            items.push({ 
                id, 
                type: SearchType.Local, 
                name, 
                category, 
                address,
                latitude,
                longitude
            } as LocalSearchResult);
          } else if (searchType === SearchType.Local && rawItem && latitude !== null && longitude !== null) { 
             items.push({ 
                id, 
                type: SearchType.Local, 
                name: name || rawItem.substring(0, Math.min(40, rawItem.length)), 
                category: category || "Local Business", 
                address: address || "Address not specified",
                latitude,
                longitude
            } as LocalSearchResult);
          } else {
            if(latitude === null || longitude === null) console.warn(`Skipping local result due to missing lat/long: ${name}`);
          }
          break;
      }
    } catch (e) {
      console.error("Error parsing item:", rawItem, e);
    }
  });
  return items;
}

export type WidgetOrAnswerData = {
  widgetType: 'DirectAnswer' | 'CurrencyConverter' | 'SportsScores' | 'WeatherInfo' | 'EntityInfoPanel' | 'SportsRanking';
  data: any; 
};

export async function* fetchSearchResultsFromGeminiStream(
  query: string,
  searchType: SearchType,
  language: Language,
  userLocation?: UserLocation,
  filters?: SearchFilterOptions,
  forceOriginalQuery?: boolean 
): AsyncGenerator<{ type: 'items'; data: SearchResultItem[] } | { type: 'sources'; data: GroundingSource[] } | { type: 'widgetOrAnswer', data: WidgetOrAnswerData } | { type: 'searchCorrection', data: { originalQuery: string, correctedQuery: string } } | { type: 'dominantPayload', data: DominantResultPayload }, void, unknown> {
  
  if (!process.env.API_KEY) {
    throw new Error(API_KEY_INVALID); // Use identifier
  }

  let promptText = `You are Secnto, Pakistan's AI-powered search engine. Your primary goal is to provide relevant search results.`;
  let shouldUseGoogleSearch = false;
  let resultCount = 20;
  let specialInstructions = "";
  let effectiveQuery = query; 

  let filterInstructionsText = "";
  if (filters) {
    if (filters.timeFilter && filters.timeFilter !== 'any') {
      if (filters.timeFilter === 'custom' && filters.customStartDate && filters.customEndDate) filterInstructionsText += ` Consider only results created or updated between ${filters.customStartDate} and ${filters.customEndDate}.`;
      else if (filters.timeFilter === 'hour') filterInstructionsText += ` Focus on results from the past hour.`;
      else if (filters.timeFilter === 'day') filterInstructionsText += ` Focus on results from the past 24 hours.`;
      else if (filters.timeFilter === 'week') filterInstructionsText += ` Focus on results from the past week.`;
      else if (filters.timeFilter === 'month') filterInstructionsText += ` Focus on results from the past month.`;
      else if (filters.timeFilter === 'year') filterInstructionsText += ` Focus on results from the past year.`;
    }
    // Image size filter is handled by fetchImagesFromGoogleCSE now.
  }


  if (searchType === SearchType.All) {
    specialInstructions = `
ATTENTION: 
1. Spell Correction:
   - First, unless 'forceOriginalQuery' is true, analyze the user's query: '${query}' in ${language}.
   - If you detect a PROBABLE misspelling and are confident in a correction, you MUST output a special JSON block BEFORE any other processing.
   - This block MUST start exactly with "#SECCORRECTION_START#" and end exactly with "#SECCORRECTION_END#".
   - The JSON inside this block MUST be: {"originalQuery": "${query.replace(/"/g, '\\"')}", "correctedQuery": "your_suggested_correction"}
   - All subsequent processing MUST then be based on this 'correctedQuery'.
   - If no misspelling or 'forceOriginalQuery' is true, proceed with '${query}'. Let this be 'effectiveQuery'.

2. Widget/Answer Generation (based on 'effectiveQuery'):
   Determine if 'effectiveQuery' is a good candidate for a direct answer, currency conversion, sports scores/schedule/rankings, weather, or entity info.
   If yes, provide this in a JSON block: #SECWIDGET_START#{"widgetType": "Type", "data": {...}}#SECWIDGET_END#.
   The "data" object MUST contain all relevant fields for that widgetType. Valid types and data structures are:
   - "DirectAnswer": { "summaryText": "Concise answer...", "source": "Source (e.g., Wikipedia)" }
   - "CurrencyConverter": { "fromCurrency": "USD", "toCurrency": "PKR", "rateText": "1 USD = 278.50 PKR", "rateValue": 278.50, "source": "Source", "lastUpdated": "YYYY-MM-DD HH:MM UTC" }
   - "SportsScores": { "tournamentName"?: "e.g., PSL 2024", "matches": [{ "matchId": "id", "team1Name": "A", "team1Score": "170/5", "team1FlagUrl"?: "url", "team2Name": "B", "team2Score": "165/8", "team2FlagUrl"?: "url", "status": "Live/Finished/Upcoming", "venue"?: "Venue", "date"?: "YYYY-MM-DD", "time"?: "HH:MM TZ", "summary"?: "Highlight", "isFinalMatch": false, "winningTeamName"?: "Winner" }], "feedTitle"?: "Updates", "sportsUpdates"?: [{ "id": "upd1", "title": "Headline", "statusOrDate": "Date/Status", "summary"?: "Brief..." }], "source"?: "Source", "lastUpdated"?: "YYYY-MM-DD HH:MM UTC" }
     (For tournaments, provide up to 10 matches. For single matches, detail that match. Include 'team1FlagUrl'/'team2FlagUrl' for national teams).
   - "SportsRanking": { "rankingTitle": "ICC T20I Batting", "rankingType": "Player/Team", "items": [{ "rank": "1", "name": "S. Yadav", "country": "India", "ratingOrPoints": "906" }], "source"?: "Source", "lastUpdated"?: "YYYY-MM-DD" }
   - "WeatherInfo": { "location": "City, Country", "temperature": "32°C", "condition": "Sunny", "icon": "sunny", "humidity": "60%", "wind": "15 km/h W", "feelsLike": "35°C", "forecast": [{ "day": "Tomorrow", "tempHigh": "33°C", "tempLow": "28°C", "condition": "Partly Cloudy", "icon": "partly_cloudy" }], "lastUpdated": "YYYY-MM-DD HH:MM UTC", "source": "AccuWeather" }
   - "EntityInfoPanel": { "entityName": "Name", "description"?: "Short desc", "wikipediaUrl"?: "url", "officialWebsite"?: "url", "socialMedia"?: [{ "platform": "Twitter", "url": "url" }], "logoUrl"?: "url" }
   CRITICAL: For ALL widgets, especially EntityInfoPanel, CurrencyConverter, SportsScores, SportsRanking, WeatherInfo, USE GOOGLE SEARCH GROUNDING for LATEST and OFFICIAL info.

3. Dominant Result Type Identification (based on 'effectiveQuery'):
   After any spell correction and widget processing, analyze 'effectiveQuery' to determine if it has a STRONG AFFINITY for a specific content type: Images, Map (Local), or Videos.
   If a strong affinity is found, you MUST output a special JSON block: #SECDOMINANT_START#{"dominantResultType": "SearchType.Images" | "SearchType.Local" | "SearchType.Videos", "data": [...]}#SECDOMINANT_END#.
   - If "dominantResultType" is "SearchType.Images", the "data" key MUST contain an array of 2-3 strings. Each string must be formatted with image details: "ImageURL: [url]\\nCaption: [caption]\\nSourceURL: [source_url]\\nPageTitle: [page_title]".
   - If "dominantResultType" is "SearchType.Local" or "SearchType.Videos", the "data" key MUST also contain an array of 2-3 strings, formatted according to the standard result formatting for Local or Video types respectively (see below), ready for parsing. Example for Local: {"dominantResultType": "SearchType.Local", "data": ["Name: Biz Name\\nCategory: Restaurant\\nAddress: 123 St, City\\nLatitude: 24.8607\\nLongitude: 67.0011", ...]}
   
After all special blocks (correction, widget, dominant type), OR if none are applicable, generate ${resultCount} standard web search results for 'effectiveQuery'.
`;
    promptText += specialInstructions;
    shouldUseGoogleSearch = true;
  }

  switch (searchType) {
    case SearchType.All:
      promptText += ` Standard web search results for the query: '${effectiveQuery}' in ${language}.${filterInstructionsText}`;
      break;
    case SearchType.News:
      promptText += ` Generate ${resultCount} news headlines and sources for the query: '${effectiveQuery}' in ${language}.${filterInstructionsText}`;
      shouldUseGoogleSearch = true; 
      break;
    case SearchType.Images:
      // This path is now primarily handled by fetchImagesFromGoogleCSE in App.tsx.
      // Throw an error to prevent accidental use of this stream for direct image search.
      console.error("fetchSearchResultsFromGeminiStream was called with SearchType.Images. This type should be handled by fetchImagesFromGoogleCSE directly in App.tsx.");
      throw new Error("PROGRAMMING_ERROR: Image search (SearchType.Images) should not be processed by fetchSearchResultsFromGeminiStream. Use fetchImagesFromGoogleCSE.");
    case SearchType.Videos:
      resultCount = 20;
      promptText += ` Generate ${resultCount} video search results related to '${effectiveQuery}' in ${language}. 
Each result MUST include:
- Title: The title of the video.
- Channel: The name of the channel.
- VideoID: For YouTube videos, provide the accurate 11-character YouTube Video ID. This VideoID MUST correspond to a video that is currently public and accessible. If you cannot find or verify such a VideoID, return 'NOT_AVAILABLE' for VideoID.
- ThumbnailURL: For non-YouTube videos OR if a valid YouTube VideoID is absolutely unobtainable, provide a direct, working ThumbnailURL to an image that visually represents the video. If this is also not available or cannot be verified as working, return 'NOT_AVAILABLE' for ThumbnailURL.
- VideoURL: For non-YouTube videos OR if a valid YouTube VideoID is absolutely unobtainable, provide a direct, working VideoURL. If this is also not available or cannot be verified as working, return 'NOT_AVAILABLE' for VideoURL.
CRITICAL: Verify all URLs and IDs are for currently available and public content. Prioritize accuracy, especially the YouTube VideoID.
${filterInstructionsText}`;
      break;
    case SearchType.Local:
      resultCount = 10; 
      promptText += ` Generate ${resultCount} local business listings relevant to '${effectiveQuery}' in ${language}.`;
      if (userLocation) promptText += ` Prioritize listings near latitude ${userLocation.latitude}, longitude ${userLocation.longitude}.`;
      else promptText += ` Focus on listings in a major Pakistani city (e.g., Karachi, Lahore, Islamabad).`;
      promptText += ` Each local result MUST include: Name, Category, full Address, Latitude (numeric), and Longitude (numeric). Ensure Latitude and Longitude are accurate for the address.${filterInstructionsText}`;
      break;
    case SearchType.Generate: // This case is handled by generateImagesFromPrompt, not this stream function.
      console.warn("fetchSearchResultsFromGeminiStream called with SearchType.Generate, which should be handled by generateImagesFromPrompt.");
      return; // Or throw error
    default:
      // Added check to ensure all SearchTypes (except Generate and Images) are handled or it errors.
      const exhaustiveCheck: never = searchType; 
      console.error(`Invalid search type '${exhaustiveCheck}' in default case for prompt generation.`);
      throw new Error(`Unsupported search type: ${exhaustiveCheck}`);
  }
  

  const standardResultFormatting = ` For each standard search result, include a 'title', a 'url', and a brief 'snippet'. The 'url' MUST be a full, valid, and plausible external https URL for the resource (e.g., https://www.example.com/article_name). If a direct external URL is genuinely not applicable for a conceptual result, you may omit the "URL:" line entirely for that specific item. Format each standard result like this:\nTitle: [title]\nURL: [url]\nSnippet: [snippet]\n---`;

  switch (searchType) {
    case SearchType.All:
    case SearchType.News:
      promptText += standardResultFormatting;
      break;
    // case SearchType.Images: // Handled above by throwing an error
    //   break;
    case SearchType.Videos:
      promptText += ` Format each result like this:\nTitle: [title]\nChannel: [channel]\nVideoID: [youtube_video_id_or_NOT_AVAILABLE]\nThumbnailURL: [direct_thumbnail_image_url_or_NOT_AVAILABLE_if_using_VideoID_for_YouTube]\nVideoURL: [direct_video_watch_url_or_NOT_AVAILABLE_if_using_VideoID_for_YouTube]\n---`;
      break;
    case SearchType.Local:
      promptText += ` Format each result like this:\nName: [name]\nCategory: [category]\nAddress: [address]\nLatitude: [latitude_value]\nLongitude: [longitude_value]\n---`;
      break;
    // case SearchType.Generate: // Already handled
    //   break;
  }

  const contents: Content = { parts: [{ text: promptText }] };
  let accumulatedText = "";
  let itemsYieldedCount = 0;
  let widgetDataFound = false;
  let searchCorrectionFound = false;
  let dominantTypePayloadFound = false;

  try {
    const stream = await ai.models.generateContentStream({
      model: "gemini-2.5-flash-preview-04-17",
      contents: contents, 
      config: {
        ...(shouldUseGoogleSearch && { tools: [{ googleSearch: {} }] }),
      }
    });

    for await (const chunk of stream) {
        const chunkText = chunk.text;
        if (chunkText) {
            accumulatedText += chunkText;
            
            if (searchType === SearchType.All && !searchCorrectionFound && !forceOriginalQuery) {
                const correctionStartMarker = "#SECCORRECTION_START#";
                const correctionEndMarker = "#SECCORRECTION_END#";
                const startIndexCorr = accumulatedText.indexOf(correctionStartMarker);
                const endIndexCorr = accumulatedText.indexOf(correctionEndMarker);

                if (startIndexCorr !== -1 && endIndexCorr !== -1 && endIndexCorr > startIndexCorr) {
                    const correctionJsonBlock = accumulatedText.substring(startIndexCorr + correctionStartMarker.length, endIndexCorr).trim();
                    if (correctionJsonBlock) {
                        try {
                            const parsedCorrectionData = JSON.parse(correctionJsonBlock) as { originalQuery: string, correctedQuery: string };
                            if (parsedCorrectionData.originalQuery && parsedCorrectionData.correctedQuery) {
                                yield { type: 'searchCorrection', data: parsedCorrectionData };
                                searchCorrectionFound = true;
                                effectiveQuery = parsedCorrectionData.correctedQuery; 
                                accumulatedText = accumulatedText.substring(endIndexCorr + correctionEndMarker.length); 
                            }
                        } catch (e) {
                            console.error("Failed to parse search correction JSON:", e, "\nBlock content:", correctionJsonBlock);
                        }
                    }
                }
            }
            
            if (searchType === SearchType.All && !widgetDataFound) {
                const widgetStartMarker = "#SECWIDGET_START#";
                const widgetEndMarker = "#SECWIDGET_END#";
                const startIndexWidget = accumulatedText.indexOf(widgetStartMarker);
                const endIndexWidget = accumulatedText.indexOf(widgetEndMarker);

                if (startIndexWidget !== -1 && endIndexWidget !== -1 && endIndexWidget > startIndexWidget) {
                    const widgetJsonBlock = accumulatedText.substring(startIndexWidget + widgetStartMarker.length, endIndexWidget).trim();
                    if (widgetJsonBlock) { 
                        try {
                            const parsedWidgetData = JSON.parse(widgetJsonBlock) as WidgetOrAnswerData;
                            yield { type: 'widgetOrAnswer', data: parsedWidgetData };
                            widgetDataFound = true; 
                            accumulatedText = accumulatedText.substring(endIndexWidget + widgetEndMarker.length);
                        } catch (e) {
                            console.error("Failed to parse widget JSON:", e, "\nBlock content:", widgetJsonBlock);
                        }
                    }
                }
            }

            if (searchType === SearchType.All && !dominantTypePayloadFound) {
                const dominantStartMarker = "#SECDOMINANT_START#";
                const dominantEndMarker = "#SECDOMINANT_END#";
                const startIndexDom = accumulatedText.indexOf(dominantStartMarker);
                const endIndexDom = accumulatedText.indexOf(dominantEndMarker);

                if (startIndexDom !== -1 && endIndexDom !== -1 && endIndexDom > startIndexDom) {
                    const dominantJsonBlock = accumulatedText.substring(startIndexDom + dominantStartMarker.length, endIndexDom).trim();
                    if (dominantJsonBlock) {
                        try {
                            const parsedDominantInfo = JSON.parse(dominantJsonBlock) as { dominantResultType: DominantResultType, data?: string[] };
                            
                            if (parsedDominantInfo.dominantResultType && parsedDominantInfo.dominantResultType !== 'None' && parsedDominantInfo.data) {
                                let dominantData: SearchResultItem[] = [];
                                if (parsedDominantInfo.dominantResultType === SearchType.Images) {
                                    parsedDominantInfo.data.forEach((itemStr, idx) => {
                                        const parsedImage = parseGeminiImageString(itemStr, effectiveQuery, 'dominant', idx);
                                        if (parsedImage) dominantData.push(parsedImage);
                                    });
                                } else if (parsedDominantInfo.dominantResultType === SearchType.Local || parsedDominantInfo.dominantResultType === SearchType.Videos) {
                                    parsedDominantInfo.data.forEach(itemStr => {
                                        const parsedItems = parseGeminiResponse(itemStr, parsedDominantInfo.dominantResultType as SearchType.Local | SearchType.Videos, effectiveQuery, language, 0);
                                        dominantData.push(...parsedItems);
                                    });
                                }
                                
                                if (dominantData.length > 0) {
                                    yield { type: 'dominantPayload', data: { dominantResultType: parsedDominantInfo.dominantResultType, data: dominantData } };
                                }
                                dominantTypePayloadFound = true;
                            }
                            accumulatedText = accumulatedText.substring(endIndexDom + dominantEndMarker.length);
                        } catch (e) {
                            console.error("Failed to parse dominant result JSON:", e, "\nBlock content:", dominantJsonBlock);
                        }
                    }
                }
            }


            let lastSeparatorIndex = 0;
            while (true) {
                const separatorIndex = accumulatedText.indexOf("---", lastSeparatorIndex);
                if (separatorIndex === -1) {
                    break; 
                }
                
                const itemBlockText = accumulatedText.substring(lastSeparatorIndex, separatorIndex).trim();
                if (itemBlockText) {
                    const parsedItems = parseGeminiResponse(itemBlockText, searchType, effectiveQuery, language, itemsYieldedCount);
                    if (parsedItems.length > 0) {
                        yield { type: 'items', data: parsedItems };
                        itemsYieldedCount += parsedItems.length;
                    }
                }
                lastSeparatorIndex = separatorIndex + 3; 
            }
            accumulatedText = accumulatedText.substring(lastSeparatorIndex); 
        }

        if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            const sourcesData = chunk.candidates[0].groundingMetadata.groundingChunks
                .filter((gc: any): gc is { web: { uri: string; title: string } } => 
                    gc && gc.web && typeof gc.web.uri === 'string' && typeof gc.web.title === 'string' 
                )
                .map(gc => ({ web: { uri: gc.web.uri, title: gc.web.title } }));
            if (sourcesData.length > 0) {
                 // yield { type: 'sources', data: sourcesData }; // Feature removed from UI
            }
        }
    }

    if (accumulatedText.trim()) {
        const parsedItems = parseGeminiResponse(accumulatedText.trim(), searchType, effectiveQuery, language, itemsYieldedCount);
         if (parsedItems.length > 0) {
            yield { type: 'items', data: parsedItems };
        }
    }

  } catch (error: any) {
    console.error('Error in fetchSearchResultsFromGeminiStream:', error);
    if (error instanceof Error) {
        const lowerCaseMessage = error.message.toLowerCase();
        if (error.name === 'TypeError' || lowerCaseMessage.includes('network error') || lowerCaseMessage.includes('failed to fetch')) {
            throw new Error(NETWORK_ERROR);
        } else if (lowerCaseMessage.includes("api key not valid")) {
             throw new Error(API_KEY_INVALID);
        } else if (lowerCaseMessage.includes("429") || lowerCaseMessage.includes("resource_exhausted")) {
            console.warn("Gemini API Error: Rate limit likely exceeded for search stream.");
            throw new Error(RATE_LIMIT_EXCEEDED);
        }
    }
    throw new Error(GENERIC_STREAM_ERROR); 
  }
}

export const fetchSearchSuggestions = async (
  query: string,
  language: Language
): Promise<SearchSuggestion[]> => {
  if (!process.env.API_KEY) {
    console.warn("API Key not configured. Cannot fetch suggestions.");
    return [];
  }
  if (!query.trim()) {
    return [];
  }

  const prompt = `You are a search suggestion generator.
Generate up to 7 relevant and concise search suggestions for the query: '${query}' in ${language}.
Format EACH suggestion EXACTLY like this, using "---" as a separator:
Text: [The suggestion text]
---
Text: [Another suggestion text]
---
... and so on.
Ensure the suggestions are diverse and helpful for completing the user's search. Prioritize common search queries.
If the query is very specific, fewer suggestions are fine.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", 
      contents: { parts: [{ text: prompt }] }, 
      config: { thinkingConfig: { thinkingBudget: 0 } } 
    });
    const responseText = response.text;
    const suggestions: SearchSuggestion[] = [];
    const rawSuggestions = responseText.split('---').map(s => s.trim()).filter(s => s);

    rawSuggestions.forEach((rawSugg, index) => {
      const lines = rawSugg.split('\n').map(line => line.trim());
      let text = '';

      lines.forEach(line => {
        if (line.toLowerCase().startsWith('text:')) {
          text = line.substring(5).trim();
        }
      });

      if (text) {
        suggestions.push({
          id: `sugg-api-${index}-${Date.now()}`,
          text,
          suggestionType: SuggestionType.API,
        });
      }
    });
    return suggestions.slice(0, 7); 
  } catch (error: any) {
    console.error('Error fetching search suggestions from Gemini API:', error);
    const message = String(error?.message || '').toLowerCase();
     if (error?.name === 'TypeError' || message.includes('network') || message.includes('failed to fetch') || message.includes("api key not valid") || message.includes("429") || message.includes("resource_exhausted")) {
        console.warn(`Gemini API Error for suggestions: ${error.message}. Returning empty suggestions.`);
    }
    return []; 
  }
};


export const fetchTrendingTopics = async (
  language: Language,
  userLocation?: UserLocation
): Promise<SearchSuggestion[]> => {
  if (!process.env.API_KEY) {
    console.warn("API Key not configured. Cannot fetch trending topics.");
    return [];
  }

  let prompt = `You are a trending topics generator for Secnto, Pakistan's AI search engine.
Generate 7 diverse and current trending search queries/topics in ${language}.
These topics should cover a mix of categories like news, general interest, entertainment, technology, and possibly images or videos if the topic is inherently visual (e.g., "beautiful landscapes in Pakistan", "latest movie trailers").
${userLocation ? `Consider trending topics relevant to the area around latitude ${userLocation.latitude}, longitude ${userLocation.longitude} if applicable, but also include broader national/international trends.` : 'Include broader national/international trends.'}

For each trending topic, provide:
1. Text: The trending search query/topic text.
2. DataType: A hint for the type of content this topic might relate to. Choose from: News, Images, Videos, Local, All.

Format EACH topic EXACTLY like this, using "---" as a separator:
Text: [The trending topic text]
DataType: [News|Images|Videos|Local|All]
---
Text: [Another trending topic text]
DataType: [News|Images|Videos|Local|All]
---
... and so on, for 7 topics.
Ensure topics are concise and engaging.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: { parts: [{ text: prompt }] }, 
      config: { thinkingConfig: { thinkingBudget: 0 } } 
    });
    const responseText = response.text;
    const trendingTopics: SearchSuggestion[] = [];
    const rawTopics = responseText.split('---').map(s => s.trim()).filter(s => s);

    rawTopics.forEach((rawTopic, index) => {
      const lines = rawTopic.split('\n').map(line => line.trim());
      let text = '';
      let dataType: SearchSuggestion['dataType'] = SearchType.All;

      lines.forEach(line => {
        if (line.toLowerCase().startsWith('text:')) {
          text = line.substring(5).trim();
        } else if (line.toLowerCase().startsWith('datatype:')) {
          const dt = line.substring(9).trim();
          if (Object.values(SearchType).includes(dt as SearchType)) {
            dataType = dt as SearchSuggestion['dataType'];
          }
        }
      });

      if (text) {
        const uniqueId = `trend-${index}-${Date.now()}`;
        trendingTopics.push({
          id: `sugg-${uniqueId}`,
          text,
          suggestionType: SuggestionType.TRENDING,
          dataType: dataType,
        });
      }
    });
    return trendingTopics.slice(0, 7); 
  } catch (error: any) {
    console.error('Error fetching trending topics from Gemini API:', error);
    const message = String(error?.message || '').toLowerCase();
     if (error?.name === 'TypeError' || message.includes('network') || message.includes('failed to fetch') || message.includes("api key not valid") || message.includes("429") || message.includes("resource_exhausted")) {
        console.warn(`Gemini API Error for trending topics: ${error.message}. Returning empty topics.`);
    }
    return [];
  }
};

export async function* streamAssistantResponse(
  messageText: string,
  existingChat: Chat | null,
  language: Language,
  onChatCreated: (newChat: Chat) => void,
  imagePayload?: { base64Data: string; mimeType: string }
): AsyncGenerator<{ textChunk: string }, void, undefined> {
  if (!process.env.API_KEY) {
    throw new Error(API_KEY_INVALID);
  }

  let chat = existingChat;

  if (!chat) {
    const systemInstruction = `You are Secnto AI Assistant. You are helpful, creative, and an expert at answering questions and providing information, including about products. Be concise and friendly. Your responses should be in ${language}. If the user provides an image, analyze the image in your response.`;
    chat = ai.chats.create({
      model: 'gemini-2.5-flash-preview-04-17',
      config: {
        systemInstruction: systemInstruction,
      },
    });
    onChatCreated(chat);
  }

  try {
    let messageContentForStream: PartListUnion; 
    if (imagePayload) {
      const imagePart: Part = {
        inlineData: {
          mimeType: imagePayload.mimeType,
          data: imagePayload.base64Data,
        },
      };
      
      if (messageText.trim()) {
        const textPart: Part = { text: messageText };
        messageContentForStream = { parts: [textPart, imagePart] }; 
      } else {
        messageContentForStream = { parts: [imagePart] }; 
      }
    } else {
      messageContentForStream = messageText; 
    }

    const stream = await chat.sendMessageStream({ message: messageContentForStream });
    for await (const chunk of stream) {
      if (chunk.text) {
        yield { textChunk: chunk.text };
      }
    }
  } catch (error: any) {
    console.error('Error streaming assistant response:', error);
    if (error instanceof Error) {
        const lowerCaseMessage = error.message.toLowerCase();
        if (error.name === 'TypeError' || lowerCaseMessage.includes('network error') || lowerCaseMessage.includes('failed to fetch')) {
            throw new Error(NETWORK_ERROR);
        } else if (lowerCaseMessage.includes("api key not valid")) {
            throw new Error(API_KEY_INVALID);
        } else if (lowerCaseMessage.includes("429") || lowerCaseMessage.includes("resource_exhausted")) {
            console.warn("Gemini API Error: Rate limit likely exceeded for assistant stream.");
            throw new Error(RATE_LIMIT_EXCEEDED);
        }
    }
    throw new Error(GENERIC_ASSISTANT_ERROR);
  }
}

export async function* streamNotebookResponse(
  sources: NotebookSource[],
  question: string,
  existingChat: Chat | null,
  language: Language,
  onChatCreated: (newChat: Chat) => void
): AsyncGenerator<{ textChunk: string }, void, undefined> {
  if (!process.env.API_KEY) {
    throw new Error(API_KEY_INVALID);
  }

  let chat = existingChat;

  const sourcesText = sources.map((source, index) => {
    const typeLabel = source.type === NotebookSourceType.URL ? 'Web Page' : 'Pasted Text';
    let contentPreview = source.content;
    if (source.type === NotebookSourceType.TEXT && source.content.length > 1500) { // Truncate long text sources for the prompt
      contentPreview = `${source.content.substring(0, 1500)}... (truncated)`;
    }
    return `
Source ${index + 1} (ID: ${source.id}, Type: ${typeLabel}):
${source.type === NotebookSourceType.URL ? `URL: ${contentPreview}` : `Content: ${contentPreview}`}
    `.trim();
  }).join('\n\n');

  const systemInstruction = `You are an AI research assistant called "AI Notebook".
Your purpose is to help users understand, synthesize, and get answers from the documents and web pages they provide.
Base your answers *only* on the information contained within the provided sources.
When you use information from a specific source, clearly indicate which source you are referring to by its ID (e.g., "According to Source [ID]...").
If the sources do not contain information to answer the question, state that clearly.
Do not use any external knowledge. Your response should be in ${language}.`;

  if (!chat) {
    chat = ai.chats.create({
      model: 'gemini-2.5-flash-preview-04-17',
      config: { systemInstruction },
    });
    onChatCreated(chat);
  }
  
  // Construct the full message including sources for the current turn
  const fullMessage = `
CONTEXTUAL SOURCES:
${sourcesText}

USER QUESTION:
"${question}"
  `.trim();

  try {
    const stream = await chat.sendMessageStream({message: fullMessage});
    for await (const chunk of stream) {
      if (chunk.text) {
        yield { textChunk: chunk.text };
      }
    }
  } catch (error: any) {
    console.error('Error streaming notebook response:', error);
     if (error instanceof Error) {
        const lowerCaseMessage = error.message.toLowerCase();
        if (error.name === 'TypeError' || lowerCaseMessage.includes('network error') || lowerCaseMessage.includes('failed to fetch')) {
            throw new Error(NETWORK_ERROR);
        } else if (lowerCaseMessage.includes("api key not valid")) {
            throw new Error(API_KEY_INVALID);
        } else if (lowerCaseMessage.includes("429") || lowerCaseMessage.includes("resource_exhausted")) {
             console.warn("Gemini API Error: Rate limit likely exceeded for notebook stream.");
            throw new Error(RATE_LIMIT_EXCEEDED);
        }
    }
    throw new Error(GENERIC_NOTEBOOK_ERROR);
  }
}


export const fetchSearchResultsFromGemini = async (
  query: string,
  searchType: SearchType,
  language: Language,
  userLocation?: UserLocation,
  filters?: SearchFilterOptions
): Promise<{ items: SearchResultItem[], sources: GroundingSource[] | undefined }> => {
  
  if (!process.env.API_KEY) {
    console.error("API Key not configured. Cannot fetch results.");
    throw new Error(API_KEY_INVALID);
  }

  let prompt = `You are Secnto, Pakistan's AI-powered search engine.`;
  let shouldUseGoogleSearch = false;
  let resultCount = 20; 
  let effectiveQuery = query;

  let filterInstructionsText = "";
  if (filters) {
    if (filters.timeFilter && filters.timeFilter !== 'any') {
        if (filters.timeFilter === 'custom' && filters.customStartDate && filters.customEndDate) filterInstructionsText += ` Consider only results created or updated between ${filters.customStartDate} and ${filters.customEndDate}.`;
        else if (filters.timeFilter === 'hour') filterInstructionsText += ` Focus on results from the past hour.`;
        else if (filters.timeFilter === 'day') filterInstructionsText += ` Focus on results from the past 24 hours.`;
        else if (filters.timeFilter === 'week') filterInstructionsText += ` Focus on results from the past week.`;
        else if (filters.timeFilter === 'month') filterInstructionsText += ` Focus on results from the past month.`;
        else if (filters.timeFilter === 'year') filterInstructionsText += ` Focus on results from the past year.`;
    }
     // Image size filter is handled by fetchImagesFromGoogleCSE now.
  }

  switch (searchType) {
    case SearchType.All:
      prompt += ` Generate ${resultCount} realistic search results for the query: '${effectiveQuery}' in ${language}.${filterInstructionsText}`;
      shouldUseGoogleSearch = true;
      break;
    case SearchType.News:
      prompt += ` Generate ${resultCount} news headlines and sources for the query: '${effectiveQuery}' in ${language}.${filterInstructionsText}`;
      shouldUseGoogleSearch = true; 
      break;
    case SearchType.Images:
      // This path should no longer be taken if App.tsx handles Images separately via CSE.
      console.error("fetchSearchResultsFromGemini (non-stream) was called with SearchType.Images. This type should be handled by fetchImagesFromGoogleCSE directly in App.tsx.");
      throw new Error("PROGRAMMING_ERROR: Image search (SearchType.Images) should not be processed by fetchSearchResultsFromGemini (non-stream). Use fetchImagesFromGoogleCSE.");
    case SearchType.Videos:
      resultCount = 20;
      prompt += ` Generate ${resultCount} video search results related to '${effectiveQuery}' in ${language}. 
Each result MUST include:
- Title: The title of the video.
- Channel: The name of the channel.
- VideoID: For YouTube videos, provide the accurate 11-character YouTube Video ID. This VideoID MUST correspond to a video that is currently public and accessible. If you cannot find or verify such a VideoID, return 'NOT_AVAILABLE' for VideoID.
- ThumbnailURL: For non-YouTube videos OR if a valid YouTube VideoID is absolutely unobtainable, provide a direct, working ThumbnailURL to an image that visually represents the video. If this is also not available or cannot be verified as working, return 'NOT_AVAILABLE' for ThumbnailURL.
- VideoURL: For non-YouTube videos OR if a valid YouTube VideoID is absolutely unobtainable, provide a direct, working VideoURL. If this is also not available or cannot be verified as working, return 'NOT_AVAILABLE' for VideoURL.
CRITICAL: Verify all URLs and IDs are for currently available and public content. Prioritize accuracy, especially the YouTube VideoID.
${filterInstructionsText}`;
      break;
    case SearchType.Local:
      resultCount = 10; 
      prompt += ` Generate ${resultCount} local business listings relevant to '${query}' in ${language}.`; // Corrected: use original query for local context
      if (userLocation) prompt += ` Prioritize listings near latitude ${userLocation.latitude}, longitude ${userLocation.longitude}.`;
      else prompt += ` Focus on listings in a major Pakistani city (e.g., Karachi, Lahore, Islamabad).`;
      prompt += ` Each local result MUST include: Name, Category, full Address, Latitude (numeric), and Longitude (numeric). Ensure Latitude and Longitude are accurate for the address.${filterInstructionsText}`;
      break;
    case SearchType.Generate: // This case is handled by generateImagesFromPrompt
      throw new Error("fetchSearchResultsFromGemini should not be called for SearchType.Generate");
    default:
      const exhaustiveCheck: never = searchType;
      console.error(`Invalid searchType '${exhaustiveCheck}' reached default in fetchSearchResultsFromGemini.`);
      throw new Error(GENERIC_GEMINI_ERROR); // Use identifier
  }
  
  const standardResultFormattingNonImage = ` For each result, include a 'title', a 'url', and a brief 'snippet'. The 'url' MUST be a full, valid, and plausible external https URL for the resource (e.g., https://www.example.com/article_name). If a direct external URL is genuinely not applicable for a conceptual result, you may omit the "URL:" line entirely for that specific item. Format each result like this:\nTitle: [title]\nURL: [url]\nSnippet: [snippet]\n---`;

  switch (searchType) {
    case SearchType.All:
    case SearchType.News:
      prompt += standardResultFormattingNonImage;
      break;
    // case SearchType.Images: // Handled above
    //   break;
    case SearchType.Videos:
      prompt += ` Format each result like this:\nTitle: [title]\nChannel: [channel]\nVideoID: [youtube_video_id_or_NOT_AVAILABLE]\nThumbnailURL: [direct_thumbnail_image_url_or_NOT_AVAILABLE_if_using_VideoID_for_YouTube]\nVideoURL: [direct_video_watch_url_or_NOT_AVAILABLE_if_using_VideoID_for_YouTube]\n---`;
      break;
    case SearchType.Local:
      prompt += ` Format each result like this:\nName: [name]\nCategory: [category]\nAddress: [address]\nLatitude: [latitude_value]\nLongitude: [longitude_value]\n---`;
      break;
    // case SearchType.Generate: // Already handled
    //   break;
  }

  const contentsForNonStream: Content = { parts: [{ text: prompt }] };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: contentsForNonStream, 
      config: {
        ...(shouldUseGoogleSearch && { tools: [{ googleSearch: {} }] }),
      }
    });
    
    const responseText = response.text;
    const parsedItems = parseGeminiResponse(responseText, searchType, query, language);
    
    let groundingSourcesData: GroundingSource[] | undefined = undefined;
    if (shouldUseGoogleSearch && response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
        groundingSourcesData = response.candidates[0].groundingMetadata.groundingChunks
            .filter((chunk: any): chunk is { web: { uri: string; title: string } } => 
                chunk && 
                typeof chunk.web === 'object' && 
                chunk.web !== null &&
                typeof chunk.web.uri === 'string' &&
                typeof chunk.web.title === 'string' 
            )
            .map(chunk => ({ web: { uri: chunk.web.uri, title: chunk.web.title } }));
    }

    return { items: parsedItems, sources: groundingSourcesData };

  } catch (error: any) {
    console.error('Error calling Gemini API (non-stream):', error);
    if (error instanceof Error) {
        const lowerCaseMessage = error.message.toLowerCase();
        if (error.name === 'TypeError' || lowerCaseMessage.includes('network error') || lowerCaseMessage.includes('failed to fetch')) {
            throw new Error(NETWORK_ERROR);
        } else if (lowerCaseMessage.includes("api key not valid")) {
             throw new Error(API_KEY_INVALID);
        } else if (lowerCaseMessage.includes("429") || lowerCaseMessage.includes("resource_exhausted")) {
            console.warn("Gemini API Error: Rate limit likely exceeded for non-stream search.");
            throw new Error(RATE_LIMIT_EXCEEDED);
        }
    }
    throw new Error(GENERIC_GEMINI_ERROR);
  } 
};


export const generateImagesFromPrompt = async (
  prompt: string,
  language: Language, // May not be directly used by Imagen, but good for consistency
  numberOfImages: number = 1
): Promise<ImageSearchResult[]> => {
  if (!process.env.API_KEY) {
    console.error("API Key not configured. Cannot generate images.");
    throw new Error(API_KEY_INVALID);
  }

  try {
    const response = await ai.models.generateImages({
      model: 'imagen-3.0-generate-002',
      prompt: prompt,
      config: { numberOfImages: numberOfImages, outputMimeType: 'image/jpeg' },
    });

    if (!response.generatedImages || response.generatedImages.length === 0) {
      return [];
    }

    return response.generatedImages.map((genImg, index) => {
      const base64ImageBytes: string = genImg.image.imageBytes;
      const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
      return {
        id: `gen-${Date.now()}-${index}`,
        type: SearchType.Generate, // Using Generate type
        imageUrl: imageUrl,
        caption: prompt, // Use the prompt as the caption
        pageTitle: language === Language.Urdu ? "AI سے تیار کردہ تصویر" : "AI Generated Image",
        sourceUrl: '#generated', // Special identifier for generated images
      };
    });
  } catch (error: any) {
    console.error('Error generating images from Gemini API:', error);
    if (error instanceof Error) {
        const lowerCaseMessage = error.message.toLowerCase();
        if (error.name === 'TypeError' || lowerCaseMessage.includes('network error') || lowerCaseMessage.includes('failed to fetch')) {
            throw new Error(NETWORK_ERROR);
        } else if (lowerCaseMessage.includes("api key not valid")) {
             throw new Error(API_KEY_INVALID);
        } else if (lowerCaseMessage.includes("429") || lowerCaseMessage.includes("resource_exhausted") || lowerCaseMessage.includes("quota")) {
            console.warn("Gemini API Error: Rate limit or quota likely exceeded for image generation.");
            throw new Error(RATE_LIMIT_EXCEEDED);
        }
    }
    throw new Error(GENERIC_IMAGE_GENERATION_ERROR);
  }
};


// New function for Vertex AI Search (Placeholder)
export const fetchSearchResultsFromVertexAI = async (
  query: string,
  language: Language,
  filters?: SearchFilterOptions
): Promise<{ items: SearchResultItem[]; sources?: GroundingSource[]; correctedQuery?: string }> => {
  // TODO: Replace with your actual Vertex AI Search endpoint and project details.
  // Example structure: const VERTEX_AI_SEARCH_ENDPOINT = `https://discoveryengine.googleapis.com/v1alpha/projects/YOUR_PROJECT_ID/locations/global/collections/default_collection/dataStores/YOUR_DATA_STORE_ID/servingConfigs/default_search:search`;
  const VERTEX_AI_SEARCH_ENDPOINT = 'https://vertexaisearch.cloud.google.com/your-specific-endpoint'; // <<< REPLACE THIS

  console.warn(`[Vertex AI Search] Using placeholder endpoint: ${VERTEX_AI_SEARCH_ENDPOINT}. You MUST replace this with your actual endpoint.`);

  // TODO: Implement proper authentication for Vertex AI Search (e.g., OAuth 2.0 with a token).
  // This will likely involve fetching a token and adding it to the Authorization header.
  // const authToken = 'YOUR_VERTEX_AI_AUTH_TOKEN'; // <<< REPLACE THIS OR IMPLEMENT TOKEN FETCHING

  const requestBody = {
    query: query,
    // pageSize: 10, // Example: How many results to fetch
    // queryExpansionSpec: { condition: "AUTO" }, // Example
    // spellCorrectionSpec: { mode: "AUTO" }, // Example
    // contentSearchSpec: { snippetSpec: { returnSnippet: true }, summarySpec: { ... } } // Example
    // Add other parameters as needed by your Vertex AI Search setup and desired features (e.g., filters, language restrictions)
  };

  try {
    // const response = await fetch(VERTEX_AI_SEARCH_ENDPOINT, {
    //   method: 'POST', // Or GET, depending on the API
    //   headers: {
    //     'Content-Type': 'application/json',
    //     // 'Authorization': `Bearer ${authToken}`, // Add your auth token here
    //     // 'X-Goog-User-Project': 'YOUR_PROJECT_ID', // May be required
    //   },
    //   body: JSON.stringify(requestBody),
    // });

    // if (!response.ok) {
    //   const errorData = await response.json();
    //   console.error('Vertex AI Search API Error:', errorData);
    //   throw new Error(`Error from Vertex AI Search API: ${errorData.error?.message || response.statusText}`);
    // }
    // const data = await response.json();

    // TODO: Parse the 'data' object from Vertex AI Search.
    // The structure of 'data.results' will depend on your Vertex AI Search configuration.
    // Below is a HYPOTHETICAL parsing example. You MUST adapt this to your actual response.
    /*
    const items: TextSearchResult[] = (data.results || []).map((item: any, index: number) => {
      // Attempt to extract title, link, and snippet. Adjust field names as necessary.
      const doc = item.document || {};
      const derivedData = doc.derivedStructData || doc.structData || {}; // Common places for fields
      
      let title = derivedData.title || derivedData.name || `Vertex Result ${index + 1}`;
      let link = derivedData.link || derivedData.url || null;
      
      let snippet = "No snippet available.";
      if (derivedData.snippets && derivedData.snippets.length > 0) {
        snippet = derivedData.snippets[0].snippet || derivedData.snippets[0].text || snippet;
      } else if (derivedData.description) {
        snippet = derivedData.description;
      }

      return {
        id: `vertex-${doc.id || `item-${Date.now()}-${index}`}`,
        type: SearchType.All, // Or SearchType.News if applicable
        title: title,
        url: link,
        snippet: snippet,
      };
    });

    const correctedQuery = data.correctedQuery || undefined;
    // const sources = data.groundingSources || undefined; // If Vertex provides grounding

    return { items, sources: undefined, correctedQuery };
    */

    // For now, returning empty results as a placeholder until actual implementation.
    console.warn("[Vertex AI Search] fetchSearchResultsFromVertexAI is a placeholder and needs to be implemented with your actual API details and parsing logic. Returning empty results.");
    if (language === Language.Urdu) {
      throw new Error("ورٹیکس اے آئی سرچ ابھی تک مکمل طور پر مربوط نہیں ہے۔");
    } else {
      throw new Error("Vertex AI Search is not yet fully integrated.");
    }
    // return { items: [], sources: undefined, correctedQuery: undefined };


  } catch (error) {
    console.error('Failed to fetch search results from Vertex AI:', error);
    throw error; // Re-throw the error to be handled by the caller
  }
};
