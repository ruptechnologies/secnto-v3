
// IMPORTANT: Replace this with your actual Firebase project configuration!
// You can find this in your Firebase project settings.
import firebase from 'firebase/compat/app'; // Import compat version of app
import 'firebase/compat/auth'; // Import compat version of auth for side effects

// import { getAnalytics } from "firebase/analytics"; // Optional: if you want to use Firebase Analytics
const firebaseConfig = {
  apiKey: "AIzaSyAs7ZBsKdNDxmIJQL06oJtwYnxjNY9mAs8",
  authDomain: "secnto-bfd36.firebaseapp.com",
  projectId: "secnto-bfd36",
  storageBucket: "secnto-bfd36.firebasestorage.app",
  messagingSenderId: "826294860854",
  appId: "1:826294860854:web:ac05175a9f6358fae32c97",
  measurementId: "G-4X97WK094N"
  // measurementId: "YOUR_MEASUREMENT_ID" // Optional: for Firebase Analytics
};

// Initialize Firebase App using compat
let app: firebase.app.App; // Type from compat
if (!firebase.apps.length) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app(); // Get default app using compat
}

// Initialize Firebase Auth service using compat
const auth = app.auth(); // Changed from firebase.auth() to app.auth()

// const analytics = getAnalytics(app); // Optional: if using v9 analytics, ensure app instance is compatible or use compat analytics

export { app, auth }; // Export compat app and auth